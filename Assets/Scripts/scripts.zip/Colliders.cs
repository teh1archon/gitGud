﻿using UnityEngine;
using System.Collections;

public class Colliders : MonoBehaviour
{

    public Transform spawn;

    Vector2 lastKnownPos;


    bool isDead = false;
    bool checkpointReached = false;

    // Use this for initialization
    void Start()
    {
        spawn.position = transform.position;
    }



    //Detects if the player passed checkpoint, if not, spawn will be at the beginning.
    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "fire") 
        {
            isDead = true;
            print("dead!");
            if (checkpointReached == true)
            {
                transform.position = lastKnownPos;
            }

            else
            {
                transform.position = spawn.position;
            }

        }

    }

    //checkpoint , saves the position of the player at the checkpoint spot.
    public void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "checkpoint")
        {
            checkpointReached = true;
            lastKnownPos = transform.position;
        }
    }

    void Update()
    {

        //checkpoint checker;
        if(checkpointReached == true)
        {
           print ("checkpoint!");
          
        }
        //if (isDead == true)
        //{
        //    if (checkpointReached == true)
        //    {
        //        transform.position = lastKnownPos;
        //    }

        //    else
        //    {
        //        transform.position = spawn.position;
        //    }
        //}

    }




}
