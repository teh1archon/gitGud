﻿using UnityEngine;
using System.Collections;

public class Jetpack : MonoBehaviour {

    public PanelController Panel_access;

    public Rigidbody2D player_rigid;
    public Transform UP;
    public Transform CrossAir;
    public GameObject character_sprite;

    public float jetpackForce;

	// Use this for initialization
	void Start () {

        
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    //Jetpack control;
    void FixedUpdate()
    {
        if (!Panel_access.panelIsOpen)
        {
            Vector3 direction = UP.transform.position - this.transform.position;

            if (Input.GetKey("space"))
            {
                //Calculating The mouse position using vectors.
                Vector3 mousePosition = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, Input.mousePosition.z - Camera.main.transform.position.z));

                //Rotates toward the mouse
                player_rigid.transform.eulerAngles = new Vector3(0, 0, Mathf.Atan2((mousePosition.y - transform.position.y), (mousePosition.x - transform.position.x)) * Mathf.Rad2Deg - 90);

                //Judge the distance from the object and the mouse
                float distanceFromObject = (Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position)).magnitude;

                //Turns on the trajectory , gives the character who using it, a boost up , in pivot direction.
                player_rigid.AddForce(CrossAir.up * jetpackForce * Time.deltaTime);
            }



        }
    }
}
